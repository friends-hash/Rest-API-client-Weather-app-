import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class RestApiClient { 
    public static void main(String[] args) {
        try {
            String apiKey = "5adc394e904c07a428d59e28242990b8";
            String city ="Pune";
            String urlString = "https://api.openweathermap.org/data/2.5/weather?q=Pune&appid=5adc394e904c07a428d59e28242990b8&units=metric";

            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            // Parse JSON
            JsonObject json = JsonParser.parseString(response.toString()).getAsJsonObject();
            String weather = json.getAsJsonArray("weather").get(0).getAsJsonObject().get("description").getAsString();
            double temp = json.getAsJsonObject("main").get("temp").getAsDouble();

            System.out.println("City: " + city);
            System.out.println("Temperature: " + temp + "°C");
            System.out.println("Weather: " + weather);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
